

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible">
            
            <strong>Error!</strong><?php echo e(session('error')); ?>

        </div>
<?php endif; ?>

<?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            
            <strong>Success</strong><?php echo e(session('success')); ?>

        </div>
<?php endif; ?><?php /**PATH D:\Work\Source Tex Portfolio\portfolio\resources\views/alert/messages.blade.php ENDPATH**/ ?>