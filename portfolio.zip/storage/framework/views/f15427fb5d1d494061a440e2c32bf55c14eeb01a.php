
<?php $__env->startSection('content'); ?>


<main>


    <div class="container-fluid px-4">
            <h1 class="mt-4">Category</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Portfolio</li>
                <li class="breadcrumb-item active">Category</li>
            </ol> 

            <div class="card mb-4"></div>

            <div>
                <form action="<?php echo e(route('admin.portfolio.category')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="form-group mb-5">
                        <label for="formGroupExampleInput"><h5>Add Category</h5></label>
                        <input type="category" class="form-control" id="formGroupExampleInput" name="category" value="">
                    </div>
                    <button type="submit"  name="submit" class="btn btn-outline-success mt-3 mb-5">submit</button>
                </form> 
            </div>
            
            <div class="card mt-5 mb-4">
            </div>
            <div>
                <table class="table table-striped">
                    <thead>
                      <tr>
                        <th scope="col">Serial</th>
                        <th scope="col">Category</th>
                        <th scope="col">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php ($count=0); ?>
                        <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($count++); ?>
                        <tr>
                            <th scope="row"><?php echo e($count); ?></th>
                            <td><?php echo e($cat->category); ?></td>
                            <td>
                                <div class="col-sm-2">
                                        <form action="<?php echo e(route('admin.portfolio.catdestroy', $cat->id)); ?>" method="POST">
                                        <form action="" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="submit"  name="submit" value="Delete" class="btn btn-outline-danger">
                                        </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
            </div>
    </div>
</main> 
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Source Tex Portfolio\portfolio\resources\views/backend/portfolio/category.blade.php ENDPATH**/ ?>