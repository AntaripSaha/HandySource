
<?php $__env->startSection('content'); ?>
<main>


    <div class="container-fluid px-4">
        <h1 class="mt-4">Home</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol> 
        <div class="card mb-4"></div>




      <div>


        <form action="<?php echo e(route('admin.home.update')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo e(method_field('PUT')); ?>

          

            <div class="row">
              <div class="from-group col-md-3 mt-2 mb-2">
                  <h4>Background Image</h4>
                  <img  height="180px" width="280px"  src="<?php echo e(url($main->img1)); ?>" class="img thumbnail">
                  <input class="mt-2" type="file" id="img1" name="img1">
              </div>
            </div>

            


            <div class="row">
                <div class="from-group col-md-3 mt-2 mb-2">
                    <h4>Background Image</h4>
                    <img  src="<?php echo e(url($main->img2)); ?>" class="img thumbnail" height="180px" width="280px" >
                    <input class="mt-2" type="file" id="img2" name="img2">
                </div>
              </div>
              <div class="row">
                <div class="from-group col-md-3 mt-2 mb-2">
                    <h4>Background Image</h4>
                    <img  height="180px" width="280px"  src="<?php echo e(url($main->img3)); ?>" class="img thumbnail">
                    <input class="mt-2" type="file" id="img3" name="img3">
                </div>
              </div>
              <div class="row">
                <div class="from-group col-md-3 mt-2 mb-2">
                    <h4>Background Image</h4>
                    <img  height="180px" width="280px"  src="<?php echo e(url($main->img4)); ?>" class="img thumbnail">
                    <input class="mt-2" type="file" id="img4" name="img4">
                </div>
              </div>
              <div class="row">
                <div class="from-group col-md-3 mt-2 mb-2">
                    <h4>Background Image</h4>
                    <img  height="180px" width="280px"  src="<?php echo e(url($main->img5)); ?>" class="img thumbnail">
                    <input class="mt-2" type="file" id="img5" name="img5">
                </div>
              </div>

            <h3>Title or Welcome Messages</h3>

            <div class="form-group mb-2">
                <label for="formGroupExampleInput"><h6>First Word/Line</h6></label>
                <input type="text" class="form-control" id="formGroupExampleInput" name="one"  value="<?php echo e($main->one); ?>">
            </div>
            <div class="form-group mb-2">
                <label for="formGroupExampleInput2"><h6>Middle Word/ Line</h6></label>
                <input type="text" class="form-control" id="formGroupExampleInput2" name="two" value="<?php echo e($main->two); ?>">
            </div>

            <div class="form-group mb-2">
                <label for="formGroupExampleInput2"><h6>Last Word/Line</h6></label>
                <input type="text" class="form-control" id="formGroupExampleInput2" name="three" value="<?php echo e($main->three); ?>">
            </div>
    

              <button type="submit"  name="submit" class="btn btn-outline-success mt-3 mb-5">submit 
              </button>

        </form> 


    </div>


</main> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Source Tex Portfolio\portfolio\resources\views/backend/home.blade.php ENDPATH**/ ?>