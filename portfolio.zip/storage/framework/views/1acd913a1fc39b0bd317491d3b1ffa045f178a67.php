<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo e($data->logo_text); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  

  <link href="<?php echo e($data->logo_img); ?>" rel="icon">
  <link href="<?php echo e($data->logo_img); ?>" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800|Montserrat:300,400,700" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('assets/vendor/aos/aos.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Reveal - v4.3.0
  * Template URL: https://bootstrapmade.com/reveal-bootstrap-corporate-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->

  
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:<?php echo e($data->email); ?>"><?php echo e($data->email); ?></a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span> <a href="tel:<?php echo e($data->phone); ?>"> <?php echo e($data->phone); ?></a> </span></i>
      </div>
      <div class="social-links d-none d-md-flex align-items-center">
        <a href="<?php echo e($data->twitter); ?>"  target="_blank" class="twitter" ><i class="bi bi-twitter"></i></a>
        <a href="<?php echo e($data->facebook); ?>"  target="_blank" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="<?php echo e($data->instagram); ?>"  target="_blank" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="<?php echo e($data->linkedin); ?>"  target="_blank" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
    </div>
  </section>
  
  <!-- End Top Bar-->

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex justify-content-between">

      <div id="logo">
        
        <!-- Uncomment below if you prefer to use an image logo -->
         <a href="/"><img style="height: 8vh" src="<?php echo e(url($data->logo_img)); ?>" alt=""></a>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#services">Services</a></li>
          <li><a class="nav-link scrollto " href="#portfolio">Gallery</a></li>
          <li><a class="nav-link scrollto " href="#testimonials">Testimonial</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          
          <!-- <li class="dropdown"><a href="#"><span>Drop Down</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
            </ul>
          </li> -->
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          <li><a class="nav-link scrollto" href="about">About</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= hero Section ======= -->
  <section id="hero">

    <div class="hero-content" data-aos="fade-up">
      <h2><?php echo e($main->one); ?> <span><?php echo e($main->two); ?></span><br><?php echo e($main->three); ?></h2>
      <div>
        <a href="#about" class="btn-get-started scrollto">Get Started</a>
        <a href="#portfolio" class="btn-projects scrollto">Our Projects</a>
      </div>
    </div>

    <div class="hero-slider swiper-container">
      <div class="swiper-wrapper">
          <div class="swiper-slide" style="background-image: url(<?php echo $main->img1?>);"></div>
          <div class="swiper-slide" style="background-image: url(<?php echo $main->img2?>);"></div>
          <div class="swiper-slide" style="background-image: url(<?php echo $main->img3?>);"></div>
          <div class="swiper-slide" style="background-image: url(<?php echo $main->img4?>);"></div>
          <div class="swiper-slide" style="background-image: url(<?php echo $main->img5?>);"></div>
        </div>
      </div>
    </div>

  </section><!-- End Hero Section -->

  <main id="main">

    

    <!-- ======= Services Section ======= -->
    <section id="services">
      <div class="container" data-aos="fade-up">
        <div class="section-header">
          <h2>Services</h2>
          <p> <?php echo e($description->service_description); ?> </p>
        </div>
        <div class="row gy-4">
                  <?php if(count($services)>0): ?>
                  <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
                      <div class="box">
                        <div class="icon"><i class="<?php echo $service->icon?>"></i></div>
                        <h4 class="title" > <a href="<?php echo e(route('service', $service->id)); ?>"><?php echo e($service->title); ?> </a></h4>
                        <p class="description"><?php echo e(Str::limit(strip_tags($service->description), 40)); ?></p>
                      </div>
                    </div>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  <?php endif; ?>
        </div>
      </div>
    </section><!-- End Services Section -->


    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">
        <div class="section-header">
          <h2>Image Gallery</h2>
          <p><?php echo e($description->img_description); ?> </p>
        </div>
        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li data-filter=".filter<?php echo $category->category?>"><?php echo e($category->category); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">
          <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-4 col-md-6 portfolio-item filter<?php echo $portfolio->category?>">
            <img style="width: 100%" src="<?php echo e(url($portfolio->small_img)); ?>">
            <div class="portfolio-info">
              <h4><?php echo e($portfolio->title); ?></h4>
              <a href="<?php echo e(url($portfolio->big_img)); ?>" data-gallery="portfolioGallery" class="portfolio-lightbox preview-link" title="<?php echo $portfolio->sub_title?> "><i class="bx bx-plus"></i>Zoom</a>
              
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </div>
      </div>
    </section><!-- End Portfolio Section -->
    
    <!-- ======= Testimonials Section ======= -->
  <section id="testimonials">
        <div class="container" data-aos="fade-up">
            <div class="section-header">
              <h2>Testimonials</h2>
              <p><?php echo e($description->testimonial_description); ?></p>
            </div>
                  <div class="testimonials-slider swiper-container" data-aos="fade-up" data-aos-delay="100">
                        <div class="swiper-wrapper">
                              <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="swiper-slide">
                                <div class="testimonial-item">
                                  <p>
                                    <img src="assets/img/quote-sign-left.png" class="quote-sign-left" alt="">
                                  <?php echo e($testimonial->quote); ?>

                                    <img src="assets/img/quote-sign-right.png" class="quote-sign-right" alt="">
                                  </p>
                                  <img src="<?php echo e(url($testimonial->img)); ?>" class="testimonial-img" alt="">
                                  <h3><?php echo e($testimonial->name); ?></h3>
                                  <h4><?php echo e($testimonial->designation); ?></h4>
                                  <h5>&nbsp</h5>
                                </div>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>
                            <div class="swiper-pagination"></div>
                  </div>
        </div>
  </section><!-- End Testimonials Section -->



    <!-- ======= Call To Action Section ======= -->
    <section id="call-to-action">
      <div class="container" data-aos="zoom-out">
        <div class="row">
          <div class="col-lg-9 text-center text-lg-start">
            <h3 class="cta-title">Call To Action</h3>
            <p class="cta-text"><?php echo e($description->call_description); ?> </p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle" href="tel:<?php echo e($data->phone); ?>">Call To Action</a>
          </div>
        </div>
      </div>
    </section><!-- End Call To Action Section -->

    <!-- ======= Team Section ======= -->
    <section id="team">
      <div class="container" data-aos="fade-up">
        <div class="section-header">
          <h2>Our Team</h2>
          <p class="cta-text"><?php echo e($description->team_description); ?> </p>
        </div>
        <div class="row">
          <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-md-6">
            <div class="member">
              <div class="pic"><img src="<?php echo e(url($team->img)); ?>" alt=""></div>
              <div class="details">
                <h4><?php echo e($team->name); ?></h4>
                <span><?php echo e($team->designation); ?></span>
                <div class="social">
                  <a href="<?php echo e($team->twitter); ?>" target="_blank"><i class="bi bi-twitter"></i></a>
                  <a href="<?php echo e($team->facebook); ?>" target="_blank"><i class="bi bi-facebook"></i></a>
                  <a href="<?php echo e($team->instagram); ?>" target="_blank"><i class="bi bi-instagram"></i></a>
                  <a href="<?php echo e($team->linkedin); ?>" target="_blank"><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section><!-- End Team Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact">
      <div class="container" data-aos="fade-up">
        <div class="section-header">
          <h2>Contact Us</h2>
          <p><?php echo e($description->contact_description); ?> </p>
        </div>

        <div class="row contact-info">

          <div class="col-md-4">
            <div class="contact-address">
              <i class="bi bi-geo-alt"></i>
              <h3>Address</h3>
              <address><?php echo e($data->address); ?></address>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-phone">
              <i class="bi bi-phone"></i>
              <h3>Phone Number</h3>
              <p><a href="tel:<?php echo e($data->phone); ?>"><?php echo e($data->phone); ?></a></p>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-email">
              <i class="bi bi-envelope"></i>
              <h3>Email</h3>
              <p><a href="mailto:<?php echo e($data->email); ?>"><?php echo e($data->email); ?></a></p>
            </div>
          </div>

        </div>
      </div>

      <div class="container mb-4">
        <?php echo $description->map; ?>

        
      </div>

      


      

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><?php echo e($data->logo_text); ?></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!--
        All the links in the footer should remain intact.
        You can delete the links only if you purchased the pro version.
        Licensing information: https://bootstrapmade.com/license/
        Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Reveal
      -->
        
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('assets/vendor/aos/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/php-email-form/validate.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

</body>

</html><?php /**PATH D:\Work\Source Tex Portfolio\portfolio\resources\views/frontend/index.blade.php ENDPATH**/ ?>