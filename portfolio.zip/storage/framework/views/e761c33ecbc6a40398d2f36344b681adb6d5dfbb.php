<?php echo e($slot); ?>

<?php /**PATH D:\Work\Source Tex Portfolio\portfolio\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>