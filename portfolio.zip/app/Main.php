<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Main extends Model
{
    
    protected $fillable =[
        'img1','img2','img3','img4','img5','one','two','three'
    ];

}
